#1
from flask import Flask,request,render_template,redirect,url_for
import re

#2
app=Flask(__name__)
#3

@app.route("/")
def index_page():
    return render_template('index.html')



@app.route("/", methods=["POST"])
def match_regex():
    regex = request.form["regex"]
    test = request.form["test"]

    matches = re.finditer(regex, test, re.MULTILINE)

    results = []
    for matchNum, match in enumerate(matches, start=1):
        result = {'matchNum': matchNum,'start': match.start(),'end': match.end(),
            'match': match.group() }
        
        results.append(result)

    return render_template('result.html', results=results)
#4
if __name__=="__main__":
    app.run(debug=True)